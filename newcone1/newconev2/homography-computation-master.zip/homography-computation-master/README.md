# homography-computation
OpenCV-Python code for calculating homography transformation.

This code is part of the material of the course [Computer Vision and Machine Perception](http://web.unibas.it/bloisi/corsi/visione-e-percezione.html) - University of Basilicata (Italy)

**This code is provided without any warranty about its usability. It is for educational purposes and should be regarded as such.**

[![homography-computation usage video](http://img.youtube.com/vi/j_EDFd9RkqE/0.jpg)](http://www.youtube.com/watch?v=j_EDFd9RkqE "OpenCV-Python example for calculating homography transformation")

